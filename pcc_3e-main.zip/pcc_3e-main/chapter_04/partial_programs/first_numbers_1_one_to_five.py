for value in range(1, 6):
    print(value)