def greet_user():
    """Display a simple greeting."""
    print("Hello!")
    
greet_user()